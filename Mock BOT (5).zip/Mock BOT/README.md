# AI Interview System

An AI-powered interview system that generates questions based on uploaded job descriptions and evaluates candidate responses.

## Features

- Upload job descriptions in PDF, Word, or Text format
- AI-generated interview questions based on the job description
- Question pattern: 1 introduction, 3 technical, and 1 behavioral question
- Real-time answer evaluation
- Modern and responsive UI

## Setup

### Backend Setup

1. Navigate to the backend directory:
   ```bash
   cd backend
   ```

2. Create a virtual environment:
   ```bash
   python -m venv venv
   ```

3. Activate the virtual environment:
   - Windows:
     ```bash
     venv\Scripts\activate
     ```
   - Unix/MacOS:
     ```bash
     source venv/bin/activate
     ```

4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

5. Set up your OpenAI API key:
   ```bash
   export OPENAI_API_KEY='your-api-key-here'  # Unix/MacOS
   set OPENAI_API_KEY=your-api-key-here       # Windows
   ```

6. Run the backend server:
   ```bash
   python app.py
   ```

### Frontend Setup

1. Navigate to the frontend directory:
   ```bash
   cd frontend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm start
   ```

## Usage

1. Open your browser and navigate to `http://localhost:3000`
2. Upload a job description file (PDF, Word, or Text format)
3. Click "Start Interview" to begin
4. Answer each question as it appears
5. Submit your answer to proceed to the next question
6. View the interview history and evaluations in real-time

## Technologies Used

- Frontend: React.js
- Backend: Flask (Python)
- AI: OpenAI GPT-3.5
- File Processing: PyPDF2, python-docx

## Performance Optimizations

The system includes several performance optimizations to reduce interview answer processing time:

### Configuration Options (in `config.py`)

- `ENABLE_VISUAL_ANALYSIS = False` - Disable visual analysis for faster processing
- `VISUAL_ANALYSIS_FREQUENCY = 3` - Process visual feedback every N answers (only if enabled)
- `ENABLE_PERFORMANCE_MONITORING = True` - Enable performance timing logs

### Optimizations Applied

1. **Faster Models**: Using `gpt-3.5-turbo` instead of `gpt-4-turbo` for evaluation
2. **Caching**: Response evaluations and visual analysis results are cached
3. **Reduced Token Usage**: Shorter prompts and lower max_tokens
4. **Optional Visual Analysis**: Can be disabled or reduced in frequency
5. **Timeouts**: Added timeouts to prevent hanging API calls
6. **Reduced Redis Saves**: Optimized data persistence frequency

### Expected Performance Improvements

- **Response Evaluation**: ~2-3 seconds (down from 5-8 seconds)
- **Visual Analysis**: ~3-5 seconds (down from 8-12 seconds) when enabled
- **Overall Processing**: ~3-5 seconds total (down from 10-15 seconds)

## Note

Make sure to keep your OpenAI API key secure and never commit it to version control. 