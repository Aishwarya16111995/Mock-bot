import logging
import PyPDF2
import docx
from io import BytesIO
import os

logger = logging.getLogger(__name__)

def extract_text_from_file(file):
    try:
        if file.filename.lower().endswith('.pdf'):
            pdf_reader = PyPDF2.PdfReader(file)
            text = ""
            for page in pdf_reader.pages:
                text += page.extract_text()
            return text
        elif file.filename.lower().endswith(('.doc', '.docx')):
            doc = docx.Document(BytesIO(file.read()))
            text = "\n".join([para.text for para in doc.paragraphs])
            return text
        elif file.filename.lower().endswith('.txt'):
            text = file.read().decode('utf-8')
            return text
        else:
            return None
    except Exception as e:
        logger.error(f"Error extracting text from file: {str(e)}")
        return None

def save_conversation_to_file(conversation_data, roll_no=None):
    try:
        filename = f"interview_conversation_{roll_no}.txt" if roll_no else "interview_conversation.txt"
        with open(filename, "a") as f:
            for item in conversation_data:
                if 'speaker' in item:
                    f.write(f"{item['speaker']}: {item['text']}\n")
                elif 'question' in item:
                    f.write(f"Question: {item['question']}\n")
    except Exception as e:
        logger.error(f"Error saving conversation to file: {str(e)}", exc_info=True)

def load_conversation_from_file(roll_no=None):
    try:
        filename = f"interview_conversation_{roll_no}.txt" if roll_no else "interview_conversation.txt"
        if not os.path.exists(filename):
            return []
        with open(filename, "r") as f:
            lines = f.readlines()
        conversation = []
        for line in lines:
            if line.startswith("bot:") or line.startswith("user:"):
                speaker, text = line.split(":", 1)
                conversation.append({"speaker": speaker.strip(), "text": text.strip()})
            elif line.startswith("Question:"):
                question = line.split(":", 1)[1].strip()
                conversation.append({"question": question})
        return conversation
    except Exception as e:
        logger.error(f"Error loading conversation from file: {str(e)}", exc_info=True)
        return [] 