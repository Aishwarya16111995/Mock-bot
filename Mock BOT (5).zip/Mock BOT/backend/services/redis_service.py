import redis
import json
import logging
from config import Config
from backend.utils.json_encoder import CustomJSONEncoder

def get_redis_connection():
    try:
        return redis.Redis(
            host=Config.SESSION_REDIS_HOST,
            port=Config.SESSION_REDIS_PORT,
            password=Config.SESSION_REDIS_PASSWORD,
            db=0,
            decode_responses=True,
            socket_connect_timeout=3,
            socket_timeout=3
        )
    except redis.ConnectionError as e:
        logging.error(f"Redis connection error: {str(e)}")
        return None

def init_interview_data():
    return {
        "questions": [],
        "answers": [],
        "ratings": [],
        "current_question": 0,
        "interview_started": False,
        "conversation_history": [],
        "jd_text": "",
        "difficulty_level": "medium",
        "student_info": {
            'name': '',
            'roll_no': '',
            'batch_no': '',
            'center': '',
            'course': '',
            'eval_date': ''
        },
        "start_time": None,
        "end_time": None,
        "visual_feedback": [],
        "last_frame_time": 0,
        "last_activity_time": None,
        "current_context": "",
        "last_speech_time": None,
        "speech_detected": False,
        "current_answer": "",
        "speech_start_time": None,
        "is_processing_answer": False,
        "interview_time_used": 0,
        "visual_feedback_data": [],
        "waiting_for_answer": False,
        "report_generated": False
    }

def get_interview_data(user_id):
    try:
        redis_conn = get_redis_connection()
        if redis_conn is None:
            from flask import current_app as app
            if not hasattr(app, 'fallback_storage'):
                app.fallback_storage = {}
            return app.fallback_storage.get(f"interview_data:{user_id}", init_interview_data())
        data = redis_conn.get(f"interview_data:{user_id}")
        if data:
            return json.loads(data)
        return init_interview_data()
    except Exception as e:
        logging.error(f"Error getting interview data: {str(e)}")
        return init_interview_data()

def save_interview_data(user_id, data):
    try:
        redis_conn = get_redis_connection()
        if redis_conn is None:
            from flask import current_app as app
            if not hasattr(app, 'fallback_storage'):
                app.fallback_storage = {}
            app.fallback_storage[f"interview_data:{user_id}"] = data
            return
        redis_conn.setex(
            f"interview_data:{user_id}",
            Config.PERMANENT_SESSION_LIFETIME,
            json.dumps(data, cls=CustomJSONEncoder)
        )
    except Exception as e:
        logging.error(f"Error saving interview data: {str(e)}")

def clear_interview_data(user_id):
    try:
        redis_conn = get_redis_connection()
        if redis_conn is None:
            from flask import current_app as app
            if hasattr(app, 'fallback_storage'):
                app.fallback_storage.pop(f"interview_data:{user_id}", None)
            return
        redis_conn.delete(f"interview_data:{user_id}")
    except Exception as e:
        logging.error(f"Error clearing interview data: {str(e)}") 