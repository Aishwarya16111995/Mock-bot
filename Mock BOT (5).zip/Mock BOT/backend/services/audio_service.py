import base64
import tempfile
from gtts import gTTS
from pydub import AudioSegment
import os
import numpy as np
import webrtcvad
import logging

logger = logging.getLogger(__name__)

VAD_SAMPLING_RATE = 16000
VAD_FRAME_DURATION = 30
VAD_MODE = 2

vad = webrtcvad.Vad()
vad.set_mode(VAD_MODE)

def text_to_speech(text):
    try:
        tts = gTTS(text=text, lang='en', slow=False)
        with tempfile.NamedTemporaryFile(delete=False, suffix='.mp3') as temp_file:
            temp_filename = temp_file.name
        tts.save(temp_filename)
        audio = AudioSegment.from_mp3(temp_filename)
        wav_filename = temp_filename.replace('.mp3', '.wav')
        audio.export(wav_filename, format="wav")
        with open(wav_filename, 'rb') as f:
            audio_data = f.read()
        os.unlink(temp_filename)
        os.unlink(wav_filename)
        return base64.b64encode(audio_data).decode('utf-8')
    except Exception as e:
        logger.error(f"Error in text-to-speech: {str(e)}", exc_info=True)
        return None

def convert_audio_to_wav(audio_bytes):
    try:
        with tempfile.NamedTemporaryFile(suffix='.mp3', delete=False) as tmp_mp3:
            tmp_mp3.write(audio_bytes)
            tmp_mp3_filename = tmp_mp3.name
        try:
            audio = AudioSegment.from_mp3(tmp_mp3_filename)
        except:
            audio = AudioSegment.from_file(tmp_mp3_filename)
        audio = audio.set_frame_rate(VAD_SAMPLING_RATE).set_channels(1)
        with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tmp_wav:
            audio.export(tmp_wav.name, format="wav")
            with open(tmp_wav.name, 'rb') as f:
                wav_data = f.read()
        os.unlink(tmp_mp3_filename)
        os.unlink(tmp_wav.name)
        return wav_data
    except Exception as e:
        logger.error(f"Error converting audio to WAV: {str(e)}")
        return None

def process_audio_with_vad(audio_bytes):
    try:
        audio = np.frombuffer(audio_bytes, dtype=np.int16)
        frame_size = int(VAD_SAMPLING_RATE * VAD_FRAME_DURATION / 1000)
        frames = [audio[i:i+frame_size] for i in range(0, len(audio), frame_size)]
        speech_frames = 0
        for frame in frames:
            if len(frame) < frame_size:
                frame = np.pad(frame, (0, frame_size - len(frame)), 'constant')
            frame_bytes = frame.tobytes()
            if vad.is_speech(frame_bytes, VAD_SAMPLING_RATE):
                speech_frames += 1
        speech_ratio = speech_frames / len(frames) if frames else 0
        has_speech = speech_ratio > 0.5
        return has_speech, speech_ratio
    except Exception as e:
        logger.error(f"Error in VAD processing: {e}", exc_info=True)
        return False, 0

def process_audio_from_base64(audio_data_base64):
    try:
        audio_bytes = base64.b64decode(audio_data_base64.split(',')[1])
        wav_data = convert_audio_to_wav(audio_bytes)
        if not wav_data:
            return False, 0
        return process_audio_with_vad(wav_data)
    except Exception as e:
        logger.error(f"Error processing audio from base64: {str(e)}", exc_info=True)
        return False, 0 