import openai
import logging
import json
import hashlib
from config import Config
from datetime import datetime
from collections import Counter
from backend.services.audio_service import text_to_speech
from backend.utils.file_utils import load_conversation_from_file
from backend.utils.performance_utils import timing_decorator

openai.api_key = Config.OPENAI_API_KEY
openai.api_base = Config.OPENAI_API_BASE
logger = logging.getLogger(__name__)

# Simple in-memory cache for response evaluations
_evaluation_cache = {}

def _get_cache_key(answer, question, difficulty_level):
    """Generate a cache key for response evaluation"""
    content = f"{answer[:100]}_{question[:100]}_{difficulty_level}"
    return hashlib.md5(content.encode()).hexdigest()

def generate_questions_from_jd(jd_text, difficulty_level, roll_no=None):
    logger.debug(f"Generating questions from JD for difficulty: {difficulty_level}")
    if not jd_text:
        logger.error("No JD text provided for question generation.")
        return []
    previous_questions = []
    filename = f"interview_conversation_{roll_no}.txt" if roll_no else "interview_conversation.txt"
    try:
        with open(filename, "r") as f:
            for line in f:
                if line.startswith("Question:"):
                    previous_questions.append(line.split(":", 1)[1].strip())
    except FileNotFoundError:
        pass
    prompt = f"""
    Generate an interview script based on the following job description. The interview should have:
    1. One introduction question
    2. Three technical questions (appropriate for {difficulty_level} level)
    3. One behavioral question
    For {difficulty_level} level, ensure the questions are:
    - Beginner: Basic concepts, simple scenarios
    - Medium: Intermediate concepts, practical applications
    - Advanced: Complex problems, in-depth analysis
    Avoid repeating these previous questions: {previous_questions[-5:] if previous_questions else "None"}
    Job Description:
    {jd_text}
    Format the output as:
    Question 1: [introduction question]
    Question 2: [technical question 1]
    Question 3: [technical question 2]
    Question 4: [technical question 3]
    Question 5: [behavioral question]
    """
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",  # Use faster model
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=1500,  # Reduced from 2000
            timeout=30  # Add timeout
        )
        if 'choices' not in response or not response['choices']:
            logger.error("No valid choices found in OpenAI response.")
            return []
        script = response.choices[0].message.content
        questions = []
        for line in script.split("\n"):
            if line.startswith("Question"):
                parts = line.split(":", 1)
                if len(parts) > 1:
                    questions.append(parts[1].strip())
        return questions[:5]
    except Exception as e:
        logger.error(f"Error generating questions: {str(e)}", exc_info=True)
        if difficulty_level == "beginner":
            return [
                "Tell us about yourself and your background.",
                "What programming languages are you familiar with?",
                "Explain a basic programming concept you've learned recently.",
                "Have you worked on any small coding projects?",
                "Describe a time when you had to learn something new quickly."
            ]
        elif difficulty_level == "advanced":
            return [
                "Walk us through your professional experience and key achievements.",
                "Explain a complex technical challenge you've solved recently.",
                "How would you design a scalable system for high traffic?",
                "Describe your approach to debugging complex issues.",
                "Tell us about a time you had to lead a technical team through a difficult project."
            ]
        else:
            return [
                "Tell us about your technical background and experience.",
                "Explain a technical concept you're comfortable with in detail.",
                "Describe a project where you implemented a technical solution.",
                "How do you approach learning new technologies?",
                "Describe a time you had to work in a team to solve a technical problem."
            ]

def generate_encouragement_prompt(conversation_history):
    try:
        prompt = f"""
        The candidate has paused during their response. Generate a brief, encouraging prompt to:
        - Help them continue their thought
        - Be supportive and professional
        - Be concise (one short sentence)
        Current conversation context:
        {conversation_history[-2:] if len(conversation_history) > 2 else conversation_history}
        Return ONLY the prompt, nothing else.
        """
        response = openai.ChatCompletion.create(
            model="gpt-4-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.5,
            max_tokens=300
        )
        encouragement = response.choices[0].message.content.strip()
        return encouragement
    except Exception as e:
        logger.error(f"Error generating encouragement prompt: {str(e)}", exc_info=True)
        return "Please continue with your thought."

@timing_decorator("Response Evaluation")
def evaluate_response(answer, question, difficulty_level, visual_feedback=None):
    # Check cache first
    cache_key = _get_cache_key(answer, question, difficulty_level)
    if cache_key in _evaluation_cache:
        logger.debug("Using cached evaluation result")
        return _evaluation_cache[cache_key]
    
    if len(answer.strip()) < 20:
        result = {
            "technical": 2.0,
            "communication": 2.0,
            "problem_solving": 2.0,
            "time_management": 2.0,
            "overall": 2.0
        }
        _evaluation_cache[cache_key] = result
        return result
    
    # Optimized prompt - shorter and more focused
    rating_prompt = f"""Rate this {difficulty_level} level interview response (1-10 each):
Q: "{question[:200]}"
A: "{answer[:300]}"
Return JSON: {{"technical": X, "communication": X, "problem_solving": X, "time_management": X, "overall": X}}"""
    
    try:
        # Use faster model for evaluation
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",  # Faster than gpt-4-turbo
            messages=[{"role": "user", "content": rating_prompt}],
            temperature=0.3,
            max_tokens=100,  # Reduced from 200
            timeout=10  # Add timeout
        )
        ratings = json.loads(response.choices[0].message.content)
        result = {k: float(v) for k, v in ratings.items()}
        
        # Cache the result
        _evaluation_cache[cache_key] = result
        
        # Limit cache size to prevent memory issues
        if len(_evaluation_cache) > 1000:
            # Remove oldest entries
            oldest_keys = list(_evaluation_cache.keys())[:100]
            for key in oldest_keys:
                del _evaluation_cache[key]
        
        return result
    except Exception as e:
        logger.error(f"Error evaluating response: {str(e)}", exc_info=True)
        result = {
            "technical": 5.0,
            "communication": 5.0,
            "problem_solving": 5.0,
            "time_management": 5.0,
            "overall": 5.0
        }
        _evaluation_cache[cache_key] = result
        return result

def generate_interview_report(interview_data):
    try:
        duration = "N/A"
        if interview_data.get('start_time') and interview_data.get('end_time'):
            try:
                if isinstance(interview_data['start_time'], str):
                    interview_data['start_time'] = datetime.fromisoformat(interview_data['start_time'])
                if isinstance(interview_data['end_time'], str):
                    interview_data['end_time'] = datetime.fromisoformat(interview_data['end_time'])
                total_secs = (interview_data['end_time'] - interview_data['start_time']).total_seconds()
                m, s = divmod(int(total_secs), 60)
                duration = f"{m}m {s}s"
            except Exception as e:
                logger.error(f"Error calculating duration: {str(e)}")
                duration = "N/A"
        avg_rating = 0.0
        if interview_data.get('ratings'):
            try:
                avg_rating = sum(r['overall'] for r in interview_data['ratings']) / len(interview_data['ratings'])
            except Exception as e:
                logger.error(f"Error calculating average rating: {str(e)}")
                avg_rating = 0.0
        avg_percentage = avg_rating * 10
        if avg_percentage >= 75:
            status = "Very Good"
            status_class = "status-Very-Good"
        elif avg_percentage >= 60:
            status = "Good"
            status_class = "status-Good"
        elif avg_percentage >= 50:
            status = "Average"
            status_class = "status-Average"
        else:
            status = "Poor"
            status_class = "status-Poor"
        conversation_history = []
        try:
            conversation_history = "\n".join(
                f"{item['speaker']}: {item['text']}" 
                for item in interview_data.get('conversation_history', [])
                if isinstance(item, dict) and 'speaker' in item and 'text' in item
            )
        except Exception as e:
            logger.error(f"Error preparing conversation history: {str(e)}")
            conversation_history = "Could not load conversation history"
        report_prompt = f"""
Generate a professional interview performance report focusing ONLY on strengths and areas for improvement. 
The report should be structured with clear sections and use only information from the interview.
Interview Difficulty Level: {interview_data['difficulty_level'].capitalize()}
Interview Duration: {duration}
Format the report with these EXACT sections:
### Key Strengths
<table class=\"report-table\">
<tr><th>Area</th><th>Examples</th><th>Rating</th></tr>
[Create table rows for each strength with specific examples from interview]
</table>
### Areas for Improvement
<table class=\"report-table\">
<tr><th>Area</th><th>Suggestions</th></tr>
[Create table rows for each improvement area with actionable suggestions]
</table>
### Visual Feedback Summary
<table class=\"report-table\">
<tr><th>Area</th><th>Feedback</th></tr>
[Create table rows for visual feedback with descriptive feedback only]
</table>
Conversation Transcript:
{conversation_history}
"""
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",  # Use faster model
            messages=[{"role": "user", "content": report_prompt}],
            temperature=0.5,
            max_tokens=1200,  # Reduced from 1500
            timeout=60  # Add timeout
        )
        report_content = response.choices[0].message.content
        rating_prompt = f"""
Based on this interview transcript, provide a JSON object with ratings (1-10) and analysis for:
1. Technical Knowledge (accuracy, depth)
2. Communication Skills (clarity, articulation)
3. Problem Solving (logic, creativity)
4. Time Management (conciseness)
5. Overall Performance (composite)
For each category, include:
- rating (1-10)
- strengths (bullet points)
- improvement_suggestions (bullet points)
Format:
{{
  "technical_knowledge": {{"rating": number, "strengths": [], "improvement_suggestions": []}},
  "communication_skills": {{"rating": number, "strengths": [], "improvement_suggestions": []}},
  "problem_solving": {{"rating": number, "strengths": [], "improvement_suggestions": []}},
  "time_management": {{"rating": number, "strengths": [], "improvement_suggestions": []}},
  "overall_performance": {{"rating": number}}
}}
Transcript:
{conversation_history}
"""
        rating_response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",  # Use faster model
            messages=[{"role": "user", "content": rating_prompt}],
            temperature=0.3,
            max_tokens=800,  # Add max tokens
            timeout=30  # Add timeout
        )
        try:
            category_ratings = json.loads(rating_response.choices[0].message.content)
            for category in category_ratings:
                if 'rating' in category_ratings[category]:
                    category_ratings[category]['rating'] = float(category_ratings[category]['rating'])
        except:
            category_ratings = {
                "technical_knowledge": {"rating": float(avg_rating), "strengths": [], "improvement_suggestions": []},
                "communication_skills": {"rating": float(avg_rating), "strengths": [], "improvement_suggestions": []},
                "problem_solving": {"rating": float(avg_rating), "strengths": [], "improvement_suggestions": []},
                "time_management": {"rating": float(avg_rating), "strengths": [], "improvement_suggestions": []},
                "overall_performance": {"rating": float(avg_rating)}
            }
        visual_feedback = {
            "professional_appearance": "No visual feedback collected",
            "body_language": "No visual feedback collected",
            "environment": "No visual feedback collected",
            "distractions": "No visual feedback collected",
            "summary": "No visual feedback was collected during this interview"
        }
        if interview_data.get('visual_feedback_data'):
            try:
                professional_appearance = []
                body_language = []
                environment = []
                distractions = []
                for feedback in interview_data['visual_feedback_data']:
                    if isinstance(feedback, dict) and 'feedback' in feedback:
                        visual_data = feedback['feedback']
                        if isinstance(visual_data, dict):
                            professional_appearance.append(visual_data.get('professional_appearance', 'No feedback'))
                            body_language.append(visual_data.get('body_language', 'No feedback'))
                            environment.append(visual_data.get('environment', 'No feedback'))
                            distractions.append(visual_data.get('distractions', 'No feedback'))
                def most_common_feedback(feedback_list):
                    if not feedback_list:
                        return "No feedback available"
                    filtered = [f for f in feedback_list if f and f.lower() != 'no feedback']
                    if not filtered:
                        return "No feedback available"
                    counts = Counter(filtered)
                    return counts.most_common(1)[0][0]
                visual_feedback = {
                    "professional_appearance": most_common_feedback(professional_appearance),
                    "body_language": most_common_feedback(body_language),
                    "environment": most_common_feedback(environment),
                    "distractions": most_common_feedback(distractions),
                    "summary": "Visual feedback collected throughout the interview"
                }
            except Exception as e:
                logger.error(f"Error processing visual feedback: {str(e)}")
                visual_feedback['summary'] = "Error processing visual feedback"
        voice_prompt = f"""
Create a concise 3-sentence spoken feedback summary based on this report:
{report_content}
The feedback should:
- Be professional and factual
- Mention one strength and one area for improvement
- Include visual feedback if available
- Be exactly 3 sentences
"""
        voice_response = openai.ChatCompletion.create(
            model="gpt-4-turbo",
            messages=[{"role": "user", "content": voice_prompt}],
            temperature=0.6
        )
        voice_feedback = voice_response.choices[0].message.content
        voice_audio = text_to_speech(voice_feedback) if voice_feedback else None
        summary_card = f"""
<div class=\"interview-summary-card\" style="
    display: flex;
    justify-content: space-between;
    background: linear-gradient(135deg,#6e8efb,#a777e3);
    padding: 1rem;
    border-radius: 8px;
    color: white;
    margin-bottom: 1rem;
    font-family: sans-serif;
">
<div>
    <div><small>Candidate Name</small><br><strong>{interview_data['student_info'].get('name', 'N/A')}</strong></div>
    <div style="margin-top:0.5rem;"><small>Roll No</small><br><strong>{interview_data['student_info'].get('roll_no', 'N/A')}</strong></div>
    <div style="margin-top:0.5rem;"><small>Batch No</small><br><strong>{interview_data['student_info'].get('batch_no', 'N/A')}</strong></div>
</div>
<div>
    <div><small>Center</small><br><strong>{interview_data['student_info'].get('center', 'N/A')}</strong></div>
    <div style="margin-top:0.5rem;"><small>Course</small><br><strong>{interview_data['student_info'].get('course', 'N/A')}</strong></div>
    <div style="margin-top:0.5rem;"><small>Evaluation Date</small><br><strong>{interview_data['student_info'].get('eval_date', 'N/A')}</strong></div>
</div>
<div style="align-self:center;">
    <span class=\"{status_class}\" style="
        background: gold;
        color: black;
        padding: 0.5rem 1rem;
        border-radius: 999px;
        font-weight: bold;
    ">{status}</span>
</div>
</div>
"""
        full_report_html = summary_card + report_content
        return {
            "status": "success",
            "report_html": full_report_html,
            "category_ratings": category_ratings,
            "voice_feedback": voice_feedback,
            "voice_audio": voice_audio,
            "status_class": status_class,
            "visual_feedback": visual_feedback
        }
    except Exception as e:
        logger.error(f"Error generating report: {str(e)}")
        return {
            "status": "error",
            "message": str(e)
        } 