import base64
import cv2
import numpy as np
import logging
import openai
import json
import hashlib
from backend.utils.performance_utils import timing_decorator

logger = logging.getLogger(__name__)

MAX_FRAME_SIZE = 500

# Cache for visual analysis results
_visual_cache = {}

def _get_visual_cache_key(frame_base64):
    """Generate a cache key for visual analysis"""
    return hashlib.md5(frame_base64.encode()).hexdigest()

def process_frame_for_gpt4v(frame):
    try:
        height, width = frame.shape[:2]
        if height > MAX_FRAME_SIZE or width > MAX_FRAME_SIZE:
            scale = MAX_FRAME_SIZE / max(height, width)
            frame = cv2.resize(frame, (int(width * scale), int(height * scale)))
        _, buffer = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 70])  # Reduce quality for faster processing
        base64_str = base64.b64encode(buffer).decode('utf-8')
        return base64_str
    except Exception as e:
        logger.error(f"Error processing frame for GPT-4V: {str(e)}")
        return ""

@timing_decorator("Visual Analysis")
def analyze_visual_response(frame_base64, conversation_context):
    # Check cache first
    cache_key = _get_visual_cache_key(frame_base64)
    if cache_key in _visual_cache:
        logger.debug("Using cached visual analysis result")
        return _visual_cache[cache_key]
    
    if not frame_base64:
        logger.error("No frame data provided to analyze_visual_response. Returning fallback feedback.")
        result = {
            "professional_appearance": "No visual feedback available (no frame data)",
            "body_language": "No visual feedback available (no frame data)",
            "environment": "No visual feedback available (no frame data)",
            "distractions": "No visual feedback available (no frame data)"
        }
        _visual_cache[cache_key] = result
        return result
    try:
        # Simplified prompt for faster processing
        prompt = f"Analyze interview candidate: appearance, body language, environment, distractions. Return JSON: {{'professional_appearance': 'desc', 'body_language': 'desc', 'environment': 'desc', 'distractions': 'desc'}}"
        
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",  # Use faster model instead of gpt-4-turbo
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{frame_base64}"
                            }
                        }
                    ]
                }
            ],
            max_tokens=150,  # Reduced from 200
            timeout=15  # Add timeout
        )
        logger.debug(f"Raw OpenAI visual feedback response: {response.choices[0].message.content}")
        try:
            feedback = json.loads(response.choices[0].message.content)
            # Cache the result
            _visual_cache[cache_key] = feedback
            
            # Limit cache size
            if len(_visual_cache) > 500:
                oldest_keys = list(_visual_cache.keys())[:50]
                for key in oldest_keys:
                    del _visual_cache[key]
            
            return feedback
        except json.JSONDecodeError:
            feedback_text = response.choices[0].message.content
            logger.error(f"OpenAI response is not valid JSON. Fallback triggered. Response: {feedback_text}")
            result = {
                "professional_appearance": "No specific feedback available",
                "body_language": "No specific feedback available",
                "environment": "No specific feedback available",
                "distractions": feedback_text
            }
            _visual_cache[cache_key] = result
            return result
    except Exception as e:
        logger.error(f"Error in visual analysis: {str(e)}", exc_info=True)
        result = {
            "professional_appearance": "No visual feedback available",
            "body_language": "No visual feedback available",
            "environment": "No visual feedback available",
            "distractions": "No visual feedback available"
        }
        _visual_cache[cache_key] = result
        return result 