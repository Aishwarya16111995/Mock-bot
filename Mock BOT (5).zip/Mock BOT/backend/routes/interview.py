from flask import Blueprint, render_template, request, session, jsonify, redirect, url_for, send_file, flash
from backend.services.redis_service import get_interview_data, save_interview_data, clear_interview_data, init_interview_data
from backend.services.snowflake_service import get_snowflake_connection
from backend.services.openai_service import (
    generate_questions_from_jd,
    generate_encouragement_prompt,
    evaluate_response,
    generate_interview_report
)
from backend.services.audio_service import text_to_speech, process_audio_from_base64
from backend.services.visual_service import process_frame_for_gpt4v, analyze_visual_response
from backend.utils.file_utils import extract_text_from_file, save_conversation_to_file, load_conversation_from_file
from config import Config
import logging
from datetime import datetime, timezone, timedelta
from collections import Counter
import os
from werkzeug.utils import secure_filename

logger = logging.getLogger(__name__)
interview_bp = Blueprint('interview', __name__)

# Interview duration in seconds (15 minutes)
INTERVIEW_DURATION = 900
# Pause threshold in seconds (15 seconds)
PAUSE_THRESHOLD = 10

def get_jd_text(jd_id):
    conn = get_snowflake_connection()
    cs = conn.cursor()
    cs.execute("SELECT jd_text FROM job_descriptions WHERE jd_id = %s", (jd_id,))
    row = cs.fetchone()
    cs.close()
    conn.close()
    return row[0] if row else None

def insert_jd(jd_text, admin_id):
    conn = get_snowflake_connection()
    cs = conn.cursor()
    # Insert the JD
    cs.execute(
        "INSERT INTO job_descriptions (jd_text, admin_id) VALUES (%s, %s)",
        (jd_text, admin_id)
    )
    # Fetch the latest jd_id for this admin and jd_text
    cs.execute(
        "SELECT jd_id FROM job_descriptions WHERE jd_text = %s AND admin_id = %s ORDER BY jd_id DESC LIMIT 1",
        (jd_text, admin_id)
    )
    row = cs.fetchone()
    jd_id = row[0] if row else None
    conn.commit()
    cs.close()
    conn.close()
    print(f"Inserted JD for admin {admin_id}, got jd_id: {jd_id}")
    return jd_id

@interview_bp.route("/interview")
def interview_bot():
    logger.debug("Interview bot route accessed")
    if "user" not in session:
        logger.warning("Unauthorized access to interview bot")
        return redirect(url_for("login"))
    email_id = session.get("user")
    interview_data = get_interview_data(email_id)
    if not interview_data:
        interview_data = init_interview_data()
        save_interview_data(email_id, interview_data)
    logger.debug("Initialized interview session data")
    return render_template("interview_bot.html")

@interview_bp.route('/start_interview', methods=['POST'])
def start_interview():
    logger.debug("Start interview endpoint called")
    if "user" not in session:
        logger.warning("Unauthenticated start interview attempt")
        return jsonify({"status": "error", "message": "Not authenticated"}), 401
    email_id = session.get("user")
    interview_data = get_interview_data(email_id) or init_interview_data()
    # Always fetch JD from DB using jd_id for this interview, ignore any cached jd_text
    if 'jd_id' in interview_data:
        interview_data['jd_text'] = get_jd_text(interview_data['jd_id'])
    # Use recruiter-uploaded JD only, do not overwrite
    if 'jd_text' not in interview_data or not interview_data['jd_text']:
        logger.error('No Job Description (JD) found for this interview. Recruiter must upload JD when scheduling.')
        return jsonify({"status": "error", "message": "No Job Description (JD) found for this interview. Please contact your recruiter."}), 400
    jd_name = interview_data['jd_text'][:30] + ('...' if len(interview_data['jd_text']) > 30 else '')
    interview_data['start_time'] = datetime.now(timezone.utc)
    interview_data['last_activity_time'] = datetime.now(timezone.utc)
    # Always reset current_question to 0 when starting interview
    interview_data['current_question'] = 0
    # ENFORCE recruiter-set difficulty level
    # If difficulty_level is not set, fetch from scheduled interview record
    if not interview_data.get('difficulty_level'):
        try:
            conn = get_snowflake_connection()
            cs = conn.cursor()
            cs.execute("""
                SELECT difficulty_level FROM interview WHERE email_id = %s ORDER BY interview_ts DESC LIMIT 1
            """, (email_id,))
            row = cs.fetchone()
            cs.close()
            conn.close()
            if row and row[0]:
                interview_data['difficulty_level'] = row[0]
            else:
                interview_data['difficulty_level'] = 'medium'
        except Exception as e:
            logger.error(f"Error fetching difficulty_level: {e}")
            interview_data['difficulty_level'] = 'medium'
    logger.debug(f"Starting interview with difficulty level: {interview_data['difficulty_level']}")
    try:
        questions = generate_questions_from_jd(
            interview_data['jd_text'],
            interview_data['difficulty_level'],
            interview_data.get('roll_no', None)
        )
        if not questions:
            logger.error("No questions generated, using fallback questions.")
            questions = ["Tell us about yourself.", "What programming languages do you know?", "Explain a basic project you've worked on."]
        interview_data['questions'] = questions
        interview_data['interview_started'] = True
        save_interview_data(email_id, interview_data)
        logger.info(f"Interview started with {len(questions)} questions")
        return jsonify({
            "status": "started",
            "total_questions": len(interview_data['questions']),
            "welcome_message": f"Welcome to the interview based on JD: {jd_name}. Let's begin with the first question.",
            "jd_name": jd_name
        })
    except Exception as e:
        logger.error(f"Error in start_interview: {str(e)}", exc_info=True)
        return jsonify({"status": "error", "message": str(e)}), 500

@interview_bp.route('/upload_jd', methods=['POST'])
def upload_jd():
    logger.debug("JD upload endpoint called")
    if "user" not in session:
        logger.warning("Unauthenticated JD upload attempt")
        return jsonify({"status": "error", "message": "Not authenticated"}), 401
    if 'jd_file' not in request.files:
        logger.warning("No file in JD upload request")
        return jsonify({"status": "error", "message": "No file uploaded"}), 400
    file = request.files['jd_file']
    if file.filename == '':
        logger.warning("Empty filename in JD upload")
        return jsonify({"status": "error", "message": "No file selected"}), 400
    logger.debug(f"Processing JD file: {file.filename}")
    jd_text = extract_text_from_file(file)
    if not jd_text or not jd_text.strip():
        flash('Could not extract text from the uploaded JD file. Please upload a valid DOCX, TXT, or text-based PDF file (not a scanned image).', 'danger')
        return render_template('schedule_interview.html', students=students, student_cols=student_cols)
    logger.info(f"Successfully extracted JD text (length: {len(jd_text)} characters)")
    admin_id = session['user']
    jd_id = insert_jd(jd_text, admin_id)
    print(f"Inserted JD: {jd_text[:30]}... by admin {admin_id}, got jd_id: {jd_id}")
    return jsonify({
        "status": "success",
        "jd_text": jd_text,
        "jd_id": jd_id
    })

@interview_bp.route('/get_question', methods=['GET'])
def get_question():
    logger.debug("Get question endpoint called")
    try:
        if "user" not in session:
            logger.warning("Unauthenticated get question attempt")
            return jsonify({"status": "error", "message": "Not authenticated"}), 401
        email_id = session.get("user")
        interview_data = get_interview_data(email_id)
        if not interview_data or not interview_data.get('interview_started', False):
            logger.warning("Attempt to get question before interview started")
            return jsonify({"status": "not_started"})
        # --- Deduplication logic start ---
        asked_questions = set()
        for entry in interview_data.get('conversation_history', []):
            if entry.get('speaker') == 'bot' and entry.get('text'):
                asked_questions.add(entry['text'].strip())
        questions = interview_data['questions']
        idx = interview_data['current_question']
        total_questions = len(questions)
        # Find the next unique question
        next_unique_idx = idx
        while next_unique_idx < total_questions and questions[next_unique_idx].strip() in asked_questions:
            next_unique_idx += 1
        if next_unique_idx >= total_questions:
            logger.info("All unique questions have been asked")
            return jsonify({"status": "completed"})
        # Update current_question pointer if we skipped duplicates
        interview_data['current_question'] = next_unique_idx
        current_q = questions[next_unique_idx]
        interview_data['conversation_history'].append({"speaker": "bot", "text": current_q})
        interview_data['current_answer'] = ""
        interview_data['waiting_for_answer'] = True
        roll_no = None
        if 'student_info' in interview_data and interview_data['student_info']:
            roll_no = interview_data['student_info'].get('roll_no')
        save_conversation_to_file([{ "speaker": "bot", "text": current_q }], roll_no)
        interview_data['last_activity_time'] = datetime.now(timezone.utc)
        save_interview_data(email_id, interview_data)
        logger.debug(f"Question {interview_data['current_question']}: {current_q[:50]}...")
        audio_data = text_to_speech(current_q)
        return jsonify({
            "status": "success",
            "question": current_q,
            "audio": audio_data,
            "question_number": interview_data['current_question'] + 1,
            "total_questions": len(interview_data['questions'])
        })
        # --- Deduplication logic end ---
    except Exception as e:
        logger.error(f"Error in get_question: {str(e)}", exc_info=True)
        return jsonify({"status": "error", "message": str(e)}), 500

@interview_bp.route('/process_answer', methods=['POST'])
def process_answer():
    logger.debug("Process answer endpoint called")
    if "user" not in session:
        logger.warning("Unauthenticated process answer attempt")
        return jsonify({"status": "error", "message": "Not authenticated"}), 401
    email_id = session.get("user")
    interview_data = get_interview_data(email_id)
    if not interview_data:
        interview_data = init_interview_data()
        interview_data['interview_started'] = True
        interview_data['current_question'] = 0
        interview_data['questions'] = []
        interview_data['conversation_history'] = []
        interview_data['answers'] = []
        interview_data['current_answer'] = ""
        interview_data['waiting_for_answer'] = False
        interview_data['interview_time_used'] = 0
    try:
        if not interview_data.get('interview_started', False):
            logger.warning("Attempt to process answer before interview started")
            return jsonify({"status": "error", "message": "Interview not started"}), 400
        data = request.get_json()
        answer = data.get('answer', '').strip()
        frame_data = data.get('frame', None)
        audio_data = data.get('audio', None)
        is_final = data.get('is_final', False)
        speaking_time = data.get('speaking_time', 0)
        logger.debug(f"Processing answer (is_final: {is_final}, speaking_time: {speaking_time}s)")
        logger.debug(f"Answer text length: {len(answer)} characters")
        interview_data['interview_time_used'] += speaking_time
        start_time = interview_data.get('start_time')
        if start_time:
            if isinstance(start_time, str):
                start_time = datetime.fromisoformat(start_time)
            elapsed = (datetime.now(timezone.utc) - start_time).total_seconds()
            if elapsed >= INTERVIEW_DURATION:
                logger.info("Interview duration limit reached (elapsed time)")
                interview_data['end_time'] = datetime.now(timezone.utc)
                save_interview_data(email_id, interview_data)
                return jsonify({
                    "status": "interview_complete",
                    "message": "Interview duration limit reached"
                })
        if not is_final:
            interview_data['current_answer'] = answer
            save_interview_data(email_id, interview_data)
            return jsonify({
                "status": "answer_accumulated",
                "remaining_time": max(0, INTERVIEW_DURATION - interview_data['interview_time_used'])
            })
        if not answer and interview_data['current_answer']:
            answer = interview_data['current_answer']
        if not answer:
            logger.warning("Empty answer received")
            return jsonify({"status": "error", "message": "Empty answer"}), 400
        if audio_data:
            try:
                logger.debug("Processing audio data with VAD")
                has_speech, speech_ratio = process_audio_from_base64(audio_data)
                interview_data['speech_detected'] = has_speech
                interview_data['last_speech_time'] = datetime.now(timezone.utc) if has_speech else None
                logger.debug(f"Speech detection - has_speech: {has_speech}, ratio: {speech_ratio:.2f}")
            except Exception as e:
                logger.error(f"Error processing audio with VAD: {str(e)}", exc_info=True)
        current_question_index = interview_data.get('current_question', 0)
        questions = interview_data.get('questions', [])
        if current_question_index < len(questions):
            current_question = questions[current_question_index]
        else:
            current_question = "Follow-up question"
        interview_data['answers'].append(answer)
        interview_data['conversation_history'].append({"speaker": "user", "text": answer})
        interview_data['current_answer'] = ""
        interview_data['waiting_for_answer'] = False
        interview_data['current_question'] += 1
        roll_no = interview_data.get('student_info', {}).get('roll_no')
        save_conversation_to_file([{ "speaker": "user", "text": answer }], roll_no)
        interview_data['last_activity_time'] = datetime.now(timezone.utc)
        # Process visual feedback if needed
        visual_feedback = None
        current_time = datetime.now().timestamp()
        if Config.ENABLE_VISUAL_ANALYSIS and frame_data and (current_time - interview_data.get('last_frame_time', 0)) > 10:
            try:
                logger.debug("Processing frame data")
                import base64
                import numpy as np
                import cv2
                frame_bytes = base64.b64decode(frame_data.split(',')[1])
                frame_array = np.frombuffer(frame_bytes, dtype=np.uint8)
                frame = cv2.imdecode(frame_array, cv2.IMREAD_COLOR)
                if frame is not None:
                    frame_base64 = process_frame_for_gpt4v(frame)
                    visual_feedback = analyze_visual_response(
                        frame_base64,
                        interview_data['conversation_history'][-3:]
                    )
                    if visual_feedback:
                        interview_data['visual_feedback'].append(visual_feedback)
                        interview_data['visual_feedback_data'].append({
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                            "feedback": visual_feedback
                        })
                        interview_data['last_frame_time'] = current_time
                        logger.debug(f"Visual feedback: {visual_feedback}")
            except Exception as e:
                logger.error(f"Error processing frame: {str(e)}", exc_info=True)
        # Evaluate the answer
        rating = evaluate_response(
            answer,
            current_question,
            interview_data.get('difficulty_level', 'medium'),
            visual_feedback
        )
        interview_data['ratings'].append(rating)
        logger.debug(f"Response rating: {rating}")
        # Save updated interview data
        save_interview_data(email_id, interview_data)
        
        # Update interview status to 'Completed' if all questions are answered
        if interview_data['current_question'] >= len(interview_data['questions']):
            interview_data['end_time'] = datetime.now(timezone.utc)
            save_interview_data(email_id, interview_data)
            try:
                conn = get_snowflake_connection()
                cs = conn.cursor()
                # Update status to 'Completed' using both email_id and interview_ts
                cs.execute("""
                    UPDATE interview 
                    SET status = 'Completed'
                    WHERE email_id = %s AND interview_ts = %s
                """, (email_id, interview_data.get('interview_ts')))
                conn.commit()
                cs.close()
                conn.close()
                logger.info(f"Updated interview status to Completed for {email_id}")
            except Exception as e:
                logger.error(f"Error updating interview status to Completed: {e}")

        return jsonify({
            "status": "answer_processed",
            "current_question": interview_data['current_question'],
            "total_questions": len(interview_data['questions']),
            "interview_complete": interview_data['current_question'] >= len(interview_data['questions']),
            "remaining_time": max(0, INTERVIEW_DURATION - interview_data['interview_time_used'])
        })
    except Exception as e:
        logger.error(f"Error in process_answer: {str(e)}", exc_info=True)
        return jsonify({"status": "error", "message": str(e)}), 500

@interview_bp.route('/check_speech', methods=['POST'])
def check_speech():
    logger.debug("Check speech endpoint called")
    if "user" not in session:
        logger.warning("Unauthenticated check speech attempt")
        return jsonify({"status": "error", "message": "Not authenticated"}), 401
    email_id = session.get("user")
    interview_data = get_interview_data(email_id)
    if not interview_data['interview_started']:
        logger.warning("Attempt to check speech before interview started")
        return jsonify({"status": "not_started"})
    data = request.get_json()
    audio_data = data.get('audio', None)
    if not audio_data:
        logger.warning("No audio data in check speech request")
        return jsonify({"status": "error", "message": "No audio data"}), 400
    try:
        logger.debug("Checking speech in audio data")
        has_speech, speech_ratio = process_audio_from_base64(audio_data)
        interview_data['speech_detected'] = has_speech
        interview_data['last_speech_time'] = datetime.now(timezone.utc) if has_speech else None
        save_interview_data(email_id, interview_data)
        speech_ended = False
        silence_duration = 0
        if interview_data['last_speech_time']:
            silence_duration = (datetime.now(timezone.utc) - interview_data['last_speech_time']).total_seconds()
            speech_ended = silence_duration > 40
        logger.debug(f"Speech detection - has_speech: {has_speech}, ratio: {speech_ratio:.2f}, silence_duration: {silence_duration:.1f}s, speech_ended: {speech_ended}")
        return jsonify({
            "status": "success",
            "speech_detected": has_speech,
            "speech_ratio": speech_ratio,
            "speech_ended": speech_ended,
            "silence_duration": silence_duration if has_speech else 0
        })
    except Exception as e:
        logger.error(f"Error checking speech: {str(e)}", exc_info=True)
        return jsonify({"status": "error", "message": str(e)}), 500

@interview_bp.route('/check_pause', methods=['GET'])
def check_pause():
    logger.debug("Check pause endpoint called")
    try:
        if "user" not in session:
            logger.warning("Unauthenticated check pause attempt")
            return jsonify({"status": "error", "message": "Not authenticated"}), 401
        email_id = session.get("user")
        interview_data = get_interview_data(email_id)
        if not interview_data.get('interview_started', False):
            logger.warning("Attempt to check pause before interview started")
            return jsonify({"status": "not_started"})
        if not interview_data.get('waiting_for_answer', False):
            logger.debug("Not waiting for answer, skip pause check")
            return jsonify({"status": "active"})
        # Remove pause detection and always return active
        return jsonify({"status": "active"})
    except Exception as e:
        logger.error(f"Error in check_pause: {str(e)}", exc_info=True)
        return jsonify({"status": "error", "message": str(e)}), 500

@interview_bp.route('/generate_report', methods=['GET'])
def generate_report():
    logger.debug("Generate report endpoint called")
    if "user" not in session:
        logger.warning("Unauthenticated generate report attempt")
        return jsonify({"status": "error", "message": "Not authenticated"}), 401
    email_id = session.get("user")
    interview_data = get_interview_data(email_id)
    if not interview_data['interview_started']:
        logger.warning("Attempt to generate report before interview started")
        return jsonify({"status": "error", "message": "Interview not started"}), 400
    if interview_data.get('report_generated', False):
        logger.debug("Report already generated, returning cached version")
        roll_no = session["user"]
        if roll_no:
            interview_data['conversation_history'] = load_conversation_from_file(roll_no)
        report = generate_interview_report(interview_data)
        return jsonify({
            "status": "success",
            "report": report['report_html'],
            "ratings": report['category_ratings'],
            "voice_feedback": report['voice_feedback'],
            "voice_audio": report['voice_audio'],
            "status_class": report['status_class'],
            "visual_feedback": report.get('visual_feedback', {})
        })
    if not interview_data['end_time']:
        interview_data['end_time'] = datetime.now(timezone.utc)
        save_interview_data(email_id, interview_data)
    
    # Ensure interview status is updated to 'Completed' in database
    try:
        conn = get_snowflake_connection()
        cs = conn.cursor()
        interview_ts = interview_data['end_time']
        # Update status to 'Completed' using both email_id and interview_ts
        cs.execute("""
            UPDATE interview 
            SET status = 'Completed'
            WHERE email_id = %s AND interview_ts = %s
        """, (email_id, interview_data.get('interview_ts')))
        conn.commit()
        cs.close()
        conn.close()
        logger.info(f"Updated interview status to Completed for {email_id}")
    except Exception as e:
        logger.error(f"Error updating interview status to Completed: {e}")

    report = generate_interview_report(interview_data)
    if report['status'] == 'error':
        logger.error(f"Error generating report: {report['message']}")
        return jsonify(report), 500
    interview_data['report_generated'] = True
    save_interview_data(email_id, interview_data)
    try:
        conn = get_snowflake_connection()
        if not conn:
            raise Exception("Could not connect to Snowflake")
        cs = conn.cursor()
        roll_no = session["user"]  # Always use roll_no from session
        interview_ts = interview_data['end_time']
        cs.execute("""
            CREATE TABLE IF NOT EXISTS interview_rating(
              roll_no TEXT,
              technical_rating FLOAT,
              communication_rating FLOAT,
              problem_solving_rating FLOAT,
              time_management_rating FLOAT,
              total_rating FLOAT,
              interview_ts TIMESTAMP
            );
        """)
        cs.execute("""
            CREATE TABLE IF NOT EXISTS student_info (
              student_name TEXT,
              roll_no TEXT,
              batch_no TEXT,
              center TEXT,
              course TEXT,
              evaluation_date TEXT,
              difficulty_level TEXT,
              interview_ts TIMESTAMP
            );
        """)
        cs.execute("""
            CREATE TABLE IF NOT EXISTS visual_feedback (
              roll_no TEXT,
              professional_appearance TEXT,
              body_language TEXT,
              environment TEXT,
              distractions TEXT,
              interview_ts TIMESTAMP,
              feedback_timestamp TIMESTAMP
            );
        """)
        cs.execute("""
            INSERT INTO interview_rating
              (roll_no, technical_rating, communication_rating,
               problem_solving_rating, time_management_rating,
               total_rating, interview_ts)
            VALUES (%s, %s, %s, %s, %s, %s, %s);
        """, (
            roll_no,
            report['category_ratings']['technical_knowledge']['rating'],
            report['category_ratings']['communication_skills']['rating'],
            report['category_ratings']['problem_solving']['rating'],
            report['category_ratings']['time_management']['rating'],
            report['category_ratings']['overall_performance']['rating'],
            interview_ts
         ))
        cs.execute("""
            INSERT INTO student_info
              (student_name, roll_no, batch_no, center, course,
               evaluation_date, difficulty_level, interview_ts)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s);
        """, (
            interview_data['student_info'].get('name', ''),
            roll_no,
            interview_data['student_info'].get('batch_no', ''),
            interview_data['student_info'].get('center', ''),
            interview_data['student_info'].get('course', ''),
            interview_data['student_info'].get('eval_date', ''),
            interview_data['difficulty_level'],
            interview_ts
         ))
        # Insert into student_performance_report if not already present
        cs.execute("""
            CREATE TABLE IF NOT EXISTS student_performance_report (
                id INTEGER AUTOINCREMENT PRIMARY KEY,
                student_name TEXT,
                roll_no TEXT,
                batch_no TEXT,
                center TEXT,
                course TEXT,
                evaluation_date TEXT,
                difficulty_level TEXT,
                interview_ts TIMESTAMP,
                report TEXT
            );
        """)
        cs.execute("SELECT COUNT(*) FROM student_performance_report WHERE roll_no = %s AND interview_ts = %s", (roll_no, interview_ts))
        already_exists = cs.fetchone()[0]
        if not already_exists:
            cs.execute("""
                INSERT INTO student_performance_report (
                    student_name, roll_no, batch_no, center, course, evaluation_date, difficulty_level, interview_ts, report
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                interview_data['student_info'].get('name', ''),
                roll_no,
                interview_data['student_info'].get('batch_no', ''),
                interview_data['student_info'].get('center', ''),
                interview_data['student_info'].get('course', ''),
                interview_data['student_info'].get('eval_date', ''),
                interview_data['difficulty_level'],
                interview_ts,
                report['report_html']
            ))
        # Insert visual feedback data if available
        if interview_data['visual_feedback_data']:
            try:
                logger.debug("Inserting visual feedback into Snowflake")
                # Get the most common feedback from all visual feedback entries
                professional_appearance = []
                body_language = []
                environment = []
                distractions = []
                
                for feedback in interview_data['visual_feedback_data']:
                    if 'feedback' in feedback and isinstance(feedback['feedback'], dict):
                        visual_data = feedback['feedback']
                        professional_appearance.append(visual_data.get('professional_appearance', 'No feedback'))
                        body_language.append(visual_data.get('body_language', 'No feedback'))
                        environment.append(visual_data.get('environment', 'No feedback'))
                        distractions.append(visual_data.get('distractions', 'No feedback'))
                
                # Get the most frequent feedback for each category
                def most_common_feedback(feedback_list):
                    if not feedback_list:
                        return "No feedback available"
                    counts = Counter(feedback_list)
                    return counts.most_common(1)[0][0]
                
                visual_feedback_data = {
                    "professional_appearance": most_common_feedback(professional_appearance),
                    "body_language": most_common_feedback(body_language),
                    "environment": most_common_feedback(environment),
                    "distractions": most_common_feedback(distractions)
                }
                
                cs.execute("""
                    INSERT INTO visual_feedback
                      (roll_no, professional_appearance, body_language,
                       environment, distractions, interview_ts)
                    VALUES (%s, %s, %s, %s, %s, %s);
                """, (
                    roll_no,
                    visual_feedback_data['professional_appearance'],
                    visual_feedback_data['body_language'],
                    visual_feedback_data['environment'],
                    visual_feedback_data['distractions'],
                    interview_ts
                ))
                logger.info("Successfully saved visual feedback to Snowflake")
            except Exception as e:
                logger.error(f"Error saving visual feedback: {str(e)}", exc_info=True)
        conn.commit()
        logger.info("Successfully saved all interview data to Snowflake")
    except Exception as e:
        logger.error(f"Snowflake insert failed: {e}")
    finally:
        if 'cs' in locals(): cs.close()
        if 'conn' in locals(): conn.close()
    return jsonify({
        "status": "success",
        "report": report['report_html'],
        "ratings": report['category_ratings'],
        "voice_feedback": report['voice_feedback'],
        "voice_audio": report['voice_audio'],
        "status_class": report['status_class'],
        "visual_feedback": report.get('visual_feedback', {})
    })

@interview_bp.route('/reset_interview', methods=['POST'])
def reset_interview():
    logger.debug("Reset interview endpoint called")
    if "user" not in session:
        logger.warning("Unauthenticated reset interview attempt")
        return jsonify({"status": "error", "message": "Not authenticated"}), 401
    email_id = session.get("user")
    clear_interview_data(email_id)
    session['interview_data'] = init_interview_data()
    logger.info("Interview session reset")
    return jsonify({"status": "success", "message": "Interview reset successfully"})

@interview_bp.route('/interview_status')
def interview_status():
    if "user" not in session:
        return jsonify({"status": "not_authenticated"}), 401
    email_id = session.get("user")
    interview_data = get_interview_data(email_id)
    return jsonify({
        "is_processing": interview_data.get('is_processing_answer', False),
        "waiting_for_answer": interview_data.get('waiting_for_answer', False),
        "current_question": interview_data.get('current_question', 0),
        "total_questions": len(interview_data.get('questions', []))
    }) 

@interview_bp.route('/scheduled_interview')
def scheduled_interview():
    if 'user' not in session or session.get('role') != 'student':
        return redirect(url_for('login'))
    email_id = session['user']
    # Fetch all scheduled interviews for this student from interview table by email_id
    conn = get_snowflake_connection()
    cs = conn.cursor()
    cs.execute("""
        SELECT student_name, roll_no, email_id, batch_no, center, course, evaluation_date, difficulty_level, interview_ts, jd_id, status
        FROM interview
        WHERE email_id = %s
        ORDER BY interview_ts DESC
    """, (email_id,))
    all_interviews = cs.fetchall()
    student_cols = [desc[0].replace('_', ' ').title() for desc in cs.description]
    cs.close()
    conn.close()
    # Add JD Name column
    student_cols.append('JD Name')
    # For each interview, get JD name
    interviews = []
    for interview in all_interviews:
        jd_id = interview[9]
        status = interview[10]
        # Get JD name (first 30 chars of JD text or 'N/A')
        jd_name = 'N/A'
        if jd_id:
            jd_text = get_jd_text(jd_id)
            if jd_text:
                jd_name = jd_text[:30] + ('...' if len(jd_text) > 30 else '')
        # Add interview_ts for use in Start Interview link
        interviews.append({
            'info': interview,
            'status': status,
            'jd_name': jd_name,
            'jd_id': jd_id,
            'interview_ts': interview[8]
        })
    return render_template('scheduled_interview.html', interviews=interviews, student_cols=student_cols)

@interview_bp.route('/start_scheduled_interview/<jd_id>/<interview_ts>', methods=['POST'])
def start_scheduled_interview(jd_id, interview_ts):
    if 'user' not in session or session.get('role') != 'student':
        return jsonify({'status': 'error', 'message': 'Unauthorized'}), 401
    email_id = session['user']
    try:
        conn = get_snowflake_connection()
        cs = conn.cursor()
        cs.execute("""
            SELECT student_name, roll_no, batch_no, center, course, evaluation_date, difficulty_level
            FROM interview
            WHERE email_id = %s AND interview_ts = %s
        """, (email_id, interview_ts))
        student_data = cs.fetchone()
        cs.close()
        conn.close()
        if not student_data:
            return "Interview not found", 404
        jd_text = get_jd_text(jd_id)
        interview_data = init_interview_data()
        interview_data['jd_id'] = jd_id
        interview_data['jd_text'] = jd_text
        interview_data['scheduled'] = True
        interview_data['interview_ts'] = interview_ts
        interview_data['difficulty_level'] = student_data[6]
        interview_data['student_info'] = {
            'name': student_data[0],
            'roll_no': student_data[1],
            'batch_no': student_data[2],
            'center': student_data[3],
            'course': student_data[4],
            'eval_date': student_data[5]
        }
        save_interview_data(email_id, interview_data)
        return redirect(url_for('interview.interview_bot'))
    except Exception as e:
        logger.error(f"Error starting scheduled interview: {e}", exc_info=True)
        return "Error starting interview", 500 

@interview_bp.route('/schedule_interview', methods=['GET', 'POST'])
def schedule_interview():
    if 'user' not in session or session.get('role') != 'recruiter':
        return redirect(url_for('auth.login'))
    conn = get_snowflake_connection()
    cs = conn.cursor()
    cs.execute("""
        SELECT si.student_name, si.roll_no, si.batch_no, si.center, si.course, si.evaluation_date, si.difficulty_level, si.interview_ts, r.email_id
        FROM student_info si
        JOIN REGISTER r ON si.roll_no = r.email_id
        ORDER BY si.interview_ts DESC
        LIMIT 200
    """)
    students = cs.fetchall()
    student_cols = [desc[0].lower() for desc in cs.description]
    cs.close()
    conn.close()
    if request.method == 'POST':
        jd_file = request.files.get('jd_file')
        student_name = request.form.get('student_name')
        roll_no = request.form.get('roll_no')
        email_id = request.form.get('email_id')
        batch_no = request.form.get('batch_no')
        center = request.form.get('center')
        course = request.form.get('course')
        evaluation_date = request.form.get('evaluation_date')
        difficulty_level = request.form.get('difficulty_level')
        if not jd_file or not student_name or not roll_no or not email_id or not batch_no or not center or not course or not evaluation_date or not difficulty_level:
            flash('Please upload a JD and fill all student information fields.', 'danger')
            return render_template('schedule_interview.html')
        filename = secure_filename(jd_file.filename)
        jd_text = extract_text_from_file(jd_file)
        jd_file.save(os.path.join('static/reports', filename))
        if not jd_text or not jd_text.strip():
            flash('Could not extract text from the uploaded JD file. Please upload a valid DOCX, TXT, or text-based PDF file (not a scanned image).', 'danger')
            return render_template('schedule_interview.html')
        admin_id = session['user']
        jd_id = insert_jd(jd_text, admin_id)
        interview_ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        conn = get_snowflake_connection()
        cs = conn.cursor()
        cs.execute("""
            CREATE TABLE IF NOT EXISTS interview (
                student_name TEXT,
                roll_no TEXT,
                email_id TEXT,
                batch_no TEXT,
                center TEXT,
                course TEXT,
                evaluation_date TEXT,
                difficulty_level TEXT,
                interview_ts TIMESTAMP,
                jd_id TEXT,
                status TEXT
            );
        """)
        cs.execute("""
            INSERT INTO interview (student_name, roll_no, email_id, batch_no, center, course, evaluation_date, difficulty_level, interview_ts, jd_id, status)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (student_name, roll_no, email_id, batch_no, center, course, evaluation_date, difficulty_level, interview_ts, jd_id, 'Scheduled'))
        conn.commit()
        cs.close()
        conn.close()
        # Save to Redis for interview flow, including difficulty_level
        interview_data = {
            'jd_text': jd_text,
            'jd_id': jd_id,
            'scheduled': True,
            'notified': False,
            'difficulty_level': difficulty_level  # ENFORCE recruiter-set difficulty
        }
        save_interview_data(roll_no, interview_data)
        flash('Interview scheduled and notification sent!', 'success')
        return render_template('schedule_interview.html', show_modal=True)
    return render_template('schedule_interview.html', students=students, student_cols=student_cols)