from flask import Blueprint, render_template, request, session, redirect, url_for, jsonify
from backend.services.snowflake_service import get_snowflake_connection
from backend.services.redis_service import clear_interview_data
from werkzeug.security import generate_password_hash, check_password_hash
import uuid
import random
import string
import logging
import smtplib
from email.mime.text import MIMEText
from config import Config

logger = logging.getLogger(__name__)
auth_bp = Blueprint('auth', __name__)

@auth_bp.route("/login", methods=["GET", "POST"])
@auth_bp.route("/", methods=["GET", "POST"])
def login():
    logger.debug(f"Login route accessed with method: {request.method}")
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        logger.debug(f"Login attempt for username: {username}")
        # Admin static login
        if username == "admin" and password == "admin123":
            logger.debug("Admin login successful")
            session["user"] = username
            session["role"] = "recruiter"
            return redirect("/recruiter_home")
        else:
            try:
                conn = get_snowflake_connection()
                if not conn:
                    raise Exception("Could not connect to Snowflake")
                cs = conn.cursor()
                logger.debug(f"Checking credentials for user: {username}")
                cs.execute("SELECT PASSWORD FROM REGISTER WHERE EMAIL_ID=%s;", (username,))
                row = cs.fetchone()
                cs.close()
                conn.close()
                if row and check_password_hash(row[0], password):
                    logger.debug("User login successful")
                    session["user"] = username  # Use email as roll_no
                    session["role"] = "student"
                    return redirect("/dashboard")
                else:
                    logger.warning("Invalid credentials")
                    return render_template("login.html", error="Invalid credentials")
            except Exception as e:
                logger.error(f"Login error: {e}")
                return render_template("login.html", error="Error during login")
    return render_template("login.html")

@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    logger.debug(f"Register route accessed with method: {request.method}")
    if request.method == "POST":
        name = request.form.get("name")
        course_name = request.form.get("course_name")
        email_id = request.form.get("email_id")
        mobile_no = request.form.get("mobile_no")
        center = request.form.get("center")
        batch_no = request.form.get("batch_no")
        password = request.form.get("password")
        logger.debug(f"Registration attempt for email: {email_id}")
        hashed_password = generate_password_hash(password)
        student_id = str(uuid.uuid4())
        try:
            conn = get_snowflake_connection()
            if not conn:
                raise Exception("Could not connect to Snowflake")
            cs = conn.cursor()
            logger.debug("Creating REGISTER table if not exists")
            cs.execute("""
CREATE TABLE IF NOT EXISTS REGISTER (
    STUDENT_ID STRING PRIMARY KEY,
    NAME STRING,
    COURSE_NAME STRING,
    EMAIL_ID STRING,
    MOBILE_NO STRING,
    CENTER STRING,
    BATCH_NO STRING,
    PASSWORD STRING,
    CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
""")
            logger.debug("Inserting new user registration")
            cs.execute("""
                INSERT INTO REGISTER (STUDENT_ID, NAME, COURSE_NAME, EMAIL_ID, MOBILE_NO, CENTER, BATCH_NO, PASSWORD)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s);
            """, (student_id, name, course_name, email_id, mobile_no, center, batch_no, hashed_password))
            conn.commit()
            cs.close()
            conn.close()
            logger.info(f"Registration successful for email: {email_id}")
            return render_template("login.html", message="Registration successful! Please login.")
        except Exception as e:
            logger.error(f"Error during registration: {e}")
            return render_template("register.html", error="Registration failed. Please try again.")
    return render_template("register.html")

@auth_bp.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    logger.debug(f"Forgot password route accessed with method: {request.method}")
    if request.method == "POST":
        email = request.form.get("username")
        if not email:
            logger.warning("Empty email in forgot password request")
            return render_template("forgot_password.html", error="Please enter your email ID")
        new_password = ''.join(random.choices(string.ascii_letters + string.digits + "!@#$%^&*", k=10))
        hashed_password = generate_password_hash(new_password)
        logger.debug(f"Password reset for email: {email}")
        try:
            conn = get_snowflake_connection()
            if not conn:
                raise Exception("Could not connect to Snowflake")
            cs = conn.cursor()
            cs.execute("SELECT * FROM REGISTER WHERE EMAIL_ID=%s", (email,))
            user = cs.fetchone()
            if not user:
                logger.warning(f"No account found for email: {email}")
                return render_template("forgot_password.html", error="No account found with that email.")
            logger.debug(f"Updating password for email: {email}")
            cs.execute("UPDATE REGISTER SET PASSWORD=%s WHERE EMAIL_ID=%s", (hashed_password, email))
            conn.commit()
            msg = MIMEText(f"""Hello,\n\nYour new password is: {new_password}\n\nPlease login here: {Config.LOGIN_URL}\nFor security, please change your password after login.\n\nThanks,\nInterview Bot Team\n""")
            msg['Subject'] = 'Password Reset - Interview Bot'
            msg['From'] = Config.OUTLOOK_EMAIL
            msg['To'] = email
            logger.debug(f"Sending password reset email to: {email}")
            with smtplib.SMTP('smtp.office365.com', 587) as server:
                server.starttls()
                server.login(Config.OUTLOOK_EMAIL, Config.OUTLOOK_PASSWORD)
                server.send_message(msg)
            cs.close()
            conn.close()
            logger.info(f"Password reset email sent to: {email}")
            return render_template("forgot_password.html", message="A new password has been sent to your email.")
        except Exception as e:
            logger.error(f"Error resetting password: {e}")
            return render_template("forgot_password.html", error="Error resetting password.")
    return render_template("forgot_password.html")

@auth_bp.route("/logout")
def logout():
    user_id = session.get("user")
    logger.debug(f"Logout requested by user: {user_id}")
    if user_id:
        clear_interview_data(user_id)
    session.clear()
    return redirect(url_for("auth.login")) 